<?php
$conn = mysqli_connect("localhost","dencoden_denco","q9Tw?~wX9-r1","dencoden_denco");

// Check connection
if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }
?>